export class Image{

  url: string;
  width:number;
  height:number;

}
